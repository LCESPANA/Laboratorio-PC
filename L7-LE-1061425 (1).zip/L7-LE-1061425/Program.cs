﻿


Console.WriteLine("Laboratorio No8 Lesther Cristopher Sthuart España Nunfio 1061425");

Console.WriteLine("Ingrese un número mayor que 0");
int n = Convert.ToInt32(Console.ReadLine());

int a = 0;
int b = 1;
int c = 0;
int i = 2;


if (n >= 0)
{
    int resultado = a;
    if (n >= 1)
    {
        resultado += b;
        while (i < n)
        {
            c = a + b;
            resultado += c;
            a = b;
            b = c;
            i = i + 1;
        }
        Console.WriteLine("tu resultado es " + resultado);
    }
    else
        resultado = b;
    Console.WriteLine("tu resultado es " + resultado);

}
else
{
    Console.WriteLine("Datos no validos");
}
 



    