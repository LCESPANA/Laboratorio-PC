﻿using System.ComponentModel.Design;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;

public class Automovil
{
    private int modelo;
    private double precio;
    private string marca;
    private bool disponible;
    private double tipoDeCambioDolar;
    private double descuentoAplicado;
    public Automovil (int modelo, double precio, string marca, bool disponible, double tipoDeCambioDolar, double descuentoAplicado)
    {
        this.modelo = 2019;
        this.precio = 10000.00d;
        this.marca = " ";
        this.disponible = false;
        this.tipoDeCambioDolar = 7.50d;
        this.descuentoAplicado = 0.00d; 
    } 
    public void DefinirModelo(int modelo)
    {
        this.modelo = modelo; 

    } 
    public void DefinirPrecio (double precio)
    {
        this.precio = precio; 
    }
    public void DefinirMarca(string marca)
    {
        this.marca = marca; 

    } 
    public void DefinirTipoDeCambio (double tipoDeCambioDolar)
    {
        this.tipoDeCambioDolar = tipoDeCambioDolar;
    }
    public void CambiarDisponibilidad()
    {
        disponible = !disponible;   
    }
    public String MostrarDisponibilidad()
    {
        if (disponible == true)
        {
            return "Disponible";

            
        }
        else
        {
            return "No se encuentra disponible actualmente";
        }
    }
    public string MostrarInformacion()
    {
        return $"Marca: {marca}. Modelo: {modelo}. Precio de venta: Q{precio}. Precio en dolares: ${precio / tipoDeCambioDolar}. {MostrarDisponibilidad()}";
    }
    public void AplicarDescuento(double miDescuento)
    {
        descuentoAplicado = miDescuento;
        double precioNuevo = precio - ((descuentoAplicado*precio)/100.00d);
        DefinirPrecio(precioNuevo);
    }

}
class Program
{
    public static void Main(string[] args)
    {
       Automovil objAutomovil = new Automovil (2020,105000.00d, "mazda", true, 7.89, 34.03d);

        Console.WriteLine($"Ingrese el modelo de su vehiculo");
        int modelo = int.Parse(Console.ReadLine());
        objAutomovil.DefinirModelo(modelo);
        Console.WriteLine($"Ingrese el precio de su vehiculo");
        double precio = double.Parse(Console.ReadLine());
        objAutomovil.DefinirPrecio(precio);
        Console.WriteLine($"Ingrese la marca de su vehiculo");
        string marca = (Console.ReadLine());
        objAutomovil.DefinirMarca(marca);
        Console.WriteLine($"Ingrese el tipo de cambio actual(Dolares $)");
        double tipoDeCambioDolar = double.Parse(Console.ReadLine());
        objAutomovil.DefinirTipoDeCambio(tipoDeCambioDolar);

        Console.WriteLine(objAutomovil.MostrarInformacion());
        int opcion = 0;
        do
        {
            Console.WriteLine($"Desea cambiar la disponibilidad {objAutomovil.MostrarDisponibilidad()}");
            Console.WriteLine($"opciones (INGRESE EL NUMERO DE LA OPCION)");
            Console.WriteLine($"1. Si");
            Console.WriteLine($"2. No");
            Console.WriteLine($"Desea añadir un descuento?");
            Console.WriteLine($"opciones (NGRESE EL NUMERO DE LA OPCION)");
            Console.WriteLine($"3. Si");
            Console.WriteLine($"4. No");
            Console.WriteLine($"5. Salir");
            opcion = int.Parse(Console.ReadLine());
            
            switch (opcion)
            {
                case 1: objAutomovil.CambiarDisponibilidad();
                    Console.WriteLine($"Cambio la disponibilidad de su automovil {objAutomovil.MostrarDisponibilidad()}"); 
                        break;
                case 2: Console.WriteLine($"No cambio la disponibilidad de su automovil");
                    break;
                case 3:
                    Console.WriteLine($"Ingrese el descuento requerido");
                    double miDescuento = double.Parse(Console.ReadLine());

                    objAutomovil.AplicarDescuento(miDescuento);
                    Console.WriteLine($"Su precio actualizado es de {precio}");
                    break;
                case 4:
                    Console.WriteLine($"No se le aplicara ningun descuento");
                    break;
            }
        } 
        while (opcion > 0 && opcion < 5);

        Console.WriteLine($"La informacion de su vehiculo es: {objAutomovil.MostrarInformacion()} ");


    }
}

