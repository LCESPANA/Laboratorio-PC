﻿using System.Globalization;

public class Estudiante
{
    string nombre;
    int carne;
    int semestre;
        public Estudiante(string nombre, int carne,  int semestre)
    {
        this.nombre = nombre;
        this.carne = carne;
        this.semestre = semestre;
        Console.WriteLine($"Nuevo estudiante regristrado");

    }
    public void identificarse()
    {
        Console.WriteLine($"Mi nombre es {this.nombre} y mi carne es {this.carne}");
    }
    public int getSemestre()
    {
        return this.semestre; 
    }
}
public class Curso
{
    string carrera;
    String nombreDeCurso;
    int seccion;
    public Curso(String carrera, string nombreDeCurso, int seccion)
    {
        this.carrera = carrera;
        this.nombreDeCurso = nombreDeCurso;
        this.seccion = seccion;
        Console.WriteLine($"nuevo curso agregado");
    }
    public void Descripcion()
    {
        Console.WriteLine($"El curso {this.nombreDeCurso} pertenece a la carrera {this.carrera}");

    }
    public int getSeccion()
    {
        return this.seccion; 
    }

}

public class Cuentabancaria
{
    string titular;
    int cuentaBancaria;
    float saldo;
    float saldoNegativo;
    float saldoPositivo;
    public Cuentabancaria(string titular, int cuentaBancaria, float saldo, float saldoNegativo, float saldoPositivo)
    {
        this.titular = titular;
        this.cuentaBancaria = cuentaBancaria;
        this.saldo = saldo;
        this.saldoNegativo = saldoNegativo;
        this.saldoPositivo = saldoPositivo;
        Console.WriteLine($"Nueva cuenta agregada");
    }
    
    public float debitar()
    {
        return this.saldo - this.saldoNegativo;
    }
    public float acreditar()
    {
        return this.saldo + this.saldoPositivo;


    }
    public float Mostrarsaldo()
    {
        return this.saldo;
    }


}



class ClaseSemana8
{
    public static void Main(string[] args)
    {
        Estudiante estudiante1 = new Estudiante("Lesther Espana", 1062425, 1);
        Estudiante estudiante2 = new Estudiante("Mauricio lopez", 104320, 9);

        estudiante1.identificarse();
        estudiante2.identificarse();
        Console.WriteLine(estudiante1.getSemestre() +" -- " +estudiante2.getSemestre());

        Curso curso1 = new Curso("Ingenieria", "precalculo", 1);
        Curso curso2 = new Curso("derecho", "introduccion al derecho", 8);

        curso1.Descripcion();
        curso2.Descripcion();

        Console.WriteLine($"el estudiante 1 esta en la seccion {curso1.getSeccion()} y el estudiante 2 esta en la seccion {curso2.getSeccion()}");

        Cuentabancaria cuenta1 = new Cuentabancaria("Lesther Espana", 1029312980, 1999.09f, 100.93f, 7000.24f);
        Cuentabancaria cuenta2 = new Cuentabancaria("William Gomez", 1043234348, 20009.09f, 990.433f, 89990.52f);

        Console.WriteLine(cuenta1.Mostrarsaldo());

        Console.WriteLine($"El saldo de la cuenta es {cuenta1.debitar()}, despues de debitar la cantidad indicada");
        Console.WriteLine($"El saldo de la cuenta es {cuenta1.acreditar()}, despues de acreditar la cantidad indicada");

        Console.WriteLine(cuenta2.Mostrarsaldo());
        Console.WriteLine($"El saldo de la cuenta es {cuenta2.debitar()}, despues de debitar la cantidad indicada");
        Console.WriteLine($"El saldo de la cuenta es {cuenta2.acreditar()}, despues de acreditar la cantidad indicada");

    }

}