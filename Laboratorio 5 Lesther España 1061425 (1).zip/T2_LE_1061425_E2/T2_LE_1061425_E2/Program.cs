﻿class Program
{
    static void Main(String[] args)
    {
        Console.WriteLine("Lesther España - 1061425- Ingrese una cantidad entre 0 y 999.99 ");
        decimal X = Convert.ToDecimal(Console.ReadLine());
        decimal billete100 = 100.00m;

        
        // Math.Floor sirve para solo obtener la parte entera 
        int cantidad1 = (int)Math.Floor(X / billete100);

        decimal residuo1 = X % billete100;

        decimal billete50 = 50.00m;
        int cantidad2 = (int)Math.Floor( residuo1/ billete50);
        decimal residuo2 = residuo1 % billete50;



        decimal billete20 = 20.00m;
        int cantidad3 = (int)Math.Floor(residuo2 / billete20);
        decimal residuo3 = residuo2 % billete20;

        decimal billete10 = 10.00m;
        int cantidad4 = (int)Math.Floor(residuo3 / billete10);
        decimal residuo4 = residuo3 % billete10;

        decimal billete5 = 5.00m;
        int cantidad5 = (int)Math.Floor(residuo4 / billete5);
        decimal residuo5 = residuo4 % billete5;

        decimal moneda1 = 1.00m;
        int cantidad6 = (int)Math.Floor(residuo5 / moneda1);
        decimal residuo6 = residuo5 % moneda1;

        decimal moneda25 = 0.25m;
        int cantidad7 = (int)Math.Floor(residuo6 / moneda25);
        decimal residuo7 = residuo6 % moneda25;

        decimal moneda1centavo = 0.01m;
        int cantidad8 = (int)Math.Floor(residuo7 / moneda1centavo);
        decimal residuo8 = residuo7 % moneda1centavo;


        Console.WriteLine("cantidad de billetes de 100:  " + cantidad1);
        Console.WriteLine("cantidad de billetes de 50:  " + cantidad2);
        Console.WriteLine("cantidad de billetes de 20:  " + cantidad3);
        Console.WriteLine("cantidad de billetes de 10:  " + cantidad4);
        Console.WriteLine("cantidad de billetes de 5:  " + cantidad5);
        Console.WriteLine("cantidad de monedas de 1 Quetzal:  " + cantidad6);
        Console.WriteLine("cantidad de monedas de 25 centavos:  " + cantidad7);
        Console.WriteLine("cantidad de monedas de 1 centavo:  " + cantidad8);
    }
}