﻿class Program
{
        static void Main(string[] args)
    {
        Console.WriteLine("Ingrese su nombre: ");
        string Nombre = Console.ReadLine();

        Console.WriteLine("Hola Mundo");
        Console.WriteLine("soy" + Nombre);
        /* Comentario */

        Console.WriteLine("Hola Mundo ");
        Console.WriteLine("soy" + Nombre);
        Console.ReadKey();
    }    
}