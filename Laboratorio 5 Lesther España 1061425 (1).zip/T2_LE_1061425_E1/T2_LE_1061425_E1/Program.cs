﻿
class Program

{
    static void Main(string[] args)
    {
        Console.WriteLine("Ingresa tu velocidad inicial: ");
        decimal VelocidadInicial = Convert.ToDecimal(Console.ReadLine());

        Console.WriteLine("Ingresa tu Aceleracion: ");
        decimal Aceleracion = Convert.ToDecimal(Console.ReadLine());

        Console.WriteLine("Ingresa tu Tiempo: ");
        decimal Tiempo = Convert.ToDecimal(Console.ReadLine());

        decimal VelocidadFinal = VelocidadInicial + (Aceleracion * Tiempo);

        Console.WriteLine("Tu velociadad Final es igual a " + VelocidadFinal);

    }

}