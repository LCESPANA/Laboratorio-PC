﻿using System.ComponentModel.Design;

Console.WriteLine("Cual es tu año de nacimiento?");
int año = Convert.ToInt32(Console.ReadLine());

Console.WriteLine("Cual es tu mes de nacimiento?");
string mesTexto = Console.ReadLine(); 


Console.WriteLine("Cual es tu dia de nacimiento?");
int dia = Convert.ToInt32(Console.ReadLine());
if (dia == 0 && dia > 31)
{
    Console.WriteLine("Datos no validos");
}

if (mesTexto != null)
{
    mesTexto = mesTexto.ToLower();
}
else
{
    Console.WriteLine("por favor ingrese un mes");
}

int MesNumero = 0;


if (mesTexto == "enero")
{
    MesNumero = MesNumero + 1;

}
else if (mesTexto == "febrero")
{
    MesNumero = MesNumero + 2;
}
else if (mesTexto == "marzo")
{
    MesNumero = MesNumero + 3;
}
else if (mesTexto == "abril")
{
    MesNumero = MesNumero + 4;
}
else if (mesTexto == "mayo")
{
    MesNumero = MesNumero + 5;
}
else if (mesTexto == "junio")
{
    MesNumero = MesNumero + 6;
}
else if (mesTexto == "julio")
{
    MesNumero = MesNumero + 7;
}
else if (mesTexto == "agosto")
{
    MesNumero = MesNumero + 8;
}
else if (mesTexto == "septiembre")
{
    MesNumero = MesNumero + 9;
}
else if (mesTexto == "octubre")
{
    MesNumero = MesNumero + 10;
}
else if (mesTexto == "noviembre")
{
    MesNumero = MesNumero + 11;
}
else if (mesTexto == "diciembre")
{
    MesNumero = MesNumero + 12;
}



if ((MesNumero == 3 && dia >= 21) || (MesNumero == 4 && dia < 19))
{
    Console.WriteLine("su signo zodiacal es: Aries");
}
if ((MesNumero == 4 && dia >= 20) || (MesNumero == 5 && dia <= 20))
{
    Console.WriteLine("su signo zodiacal es: Tauro");
}
if ((MesNumero == 5 && dia >= 21) || (MesNumero == 6 && dia <= 20))
{
    Console.WriteLine("su signo zodiacal es: geminis");
}
if ((MesNumero == 6 && dia >= 21) || (MesNumero == 7 && dia <= 22))
{
    Console.WriteLine("su signo zodiacal es: cancer");
}
if ((MesNumero == 7 && dia >= 23) || (MesNumero == 8 && dia <= 22))
{
    Console.WriteLine("su signo zodiacal es: leo");
}
if ((MesNumero == 8 && dia >= 23) || (MesNumero == 9 && dia <= 22))
{
    Console.WriteLine("su signo zodiacal es: Virgo");
}
if ((MesNumero == 9 && dia >= 23) || (MesNumero == 10 && dia <= 21))
{
    Console.WriteLine("su signo zodiacal es: libra");
}
else if ((MesNumero == 10 && dia >= 23) || (MesNumero ==11 && dia <= 21))
{
    Console.WriteLine("su signo zodiacal es: escorpio");
}
else if ((MesNumero == 11 && dia >= 22) || (MesNumero == 12 && dia <= 21))
{
    Console.WriteLine("su signo zodiacal es: sagitario");
}
else if ((MesNumero == 12 && dia >= 22) || (MesNumero == 1 && dia <= 19))
{
    Console.WriteLine("su signo zodiacal es: capricornio");
}
else if ((MesNumero == 1 && dia >= 20) || (MesNumero == 2 && dia <= 18))
{
    Console.WriteLine("su signo zodiacal es: acuario");
}
else if ((MesNumero == 2 && dia >= 19) || (MesNumero == 3 && dia <= 20))
{
    Console.WriteLine("su signo zodiacal es: piscis");
}