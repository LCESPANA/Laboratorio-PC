﻿Console.WriteLine("Ingrese el dato A ");
int a = Convert.ToInt32(Console.ReadLine());
Console.WriteLine("Ingrese el dato B ");
int b = Convert.ToInt32(Console.ReadLine());
Console.WriteLine("Ingrese el dato C ");
int c = Convert.ToInt32(Console.ReadLine());

if (a>b)
{
    if (a > c)
    {
        Console.WriteLine("A es el Dato Mayor");

    }
    else if (a == c)
    {
        Console.WriteLine("A y C son los datos mayores");
    }
    else
    {
        Console.WriteLine("C es el dato mayor");
    }
}
else if (a == b)
{
    if (a > c)
    {
        Console.WriteLine("A y B son los datos mayores");
    }
    else if (a == c)
    {
        Console.WriteLine("Los tres datos son iguales");

    }
    else
    {
        Console.WriteLine("C es el dato mayor");
    }

    

}
else if (b>a)
{
    if (b > c)
    {
        Console.WriteLine("B es el dato mayor");
    }
    else if (b == c)
    {
        Console.WriteLine("b y c son los datos mayores");
    }
}