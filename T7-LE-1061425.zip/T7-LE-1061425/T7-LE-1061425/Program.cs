﻿using System.Text;

decimal numero_1 = 0;
decimal i = 1;
decimal resultado_1 = 0;
decimal resultado_2 = 0;
decimal resultado_3 = 0;
decimal x = 0;
decimal a = 0;


Console.WriteLine("ingrese un número entero mayor a 0 ");
numero_1 = Convert.ToDecimal(Console.ReadLine());

if (numero_1 > 0)
{
    while (i <= numero_1)
    {
        resultado_1 = resultado_1 + (1m / i) ;
        i = 1 + i;


    }
    Console.WriteLine("el resultado de la operacion  (1 / 1) + (1 / 2) + (1 / 3) + … + (1 / N) " + resultado_1);
    
    
    
    
    //reiniciar el valor de i para que el bucle funcione 
    
    i = 1;    
    
    while (i <= numero_1)
    { 
        resultado_2 = resultado_2 + (decimal)Math.Pow(1.0 / 2.0 , (double)i);
    
        
        i = i + 1;
    }
    Console.WriteLine("el resultado de  (1 / 2^1) + (1 / 2^2) + (1 / 2^3) + … + (1 / 2^N) " + resultado_2);
    
    
    Console.WriteLine("ingrese un numero entero mayor a 0 que represente x ");
    x = Convert.ToDecimal(Console.ReadLine());
    Console.WriteLine("ingrese un numero entero mayor a 0 que represente a ");
    a = Convert.ToDecimal(Console.ReadLine());
    
    
    
    i = 0;
    while (i <= numero_1) 
    {
        resultado_3 += (decimal)Math.Pow((double)x, (double)i) *(decimal)Math.Pow((double)a, (double)numero_1 - (double)i);
        i += 1;
    }
    Console.WriteLine("el resultado de la operacion  c es " + resultado_3);
} 