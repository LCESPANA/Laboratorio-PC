﻿long numero = 0;
int resultado1 = 1;
long resultado2 = 1;
int resultado3 = 1;
int i = 2;
string tablasDemultiplicar = "";


Console.WriteLine("escriba un numero entero ");
numero = long.Parse(Console.ReadLine());
int opcion = 0;

if (numero >= 0)
{
        do
        {
            Console.WriteLine("elija una operacion");
            Console.WriteLine("1.) Sumatoria");
            Console.WriteLine("2.) Factorial");
            Console.WriteLine("3.) Tablas de multiplicar");
            Console.WriteLine("4.) salir");
            opcion = Convert.ToInt32(Console.ReadLine());


        switch (opcion)
        {
            case 1:
                while (i <= numero)
                {
                    resultado1 = resultado1 + i;
                    i = i + 1;
                }
                Console.WriteLine("el resultado de la sumatoria es = " + resultado1);
                break;
            case 2:
                for (long j = 1; j <= numero; j++)
                {
                    resultado2 *= j; 
                }
                Console.WriteLine("el factorial de " + numero + " es  " + resultado2);

                    break;
            case 3:
                for (int p = 1; p <11; p++)
                
                {
                    for (int m = 1; m < 11; m++)
                    {
                        resultado3 = p * m;
                        tablasDemultiplicar += resultado3.ToString() + "\t";
                       

                        
                    }
                    tablasDemultiplicar += "\n";
                }
                Console.WriteLine(tablasDemultiplicar);
                break;
            }


        }
        while (opcion > 0 && opcion < 4);

}
else if (numero == 1)
{
    Console.WriteLine(" El resultado es igual = " + resultado1);
}
else
{
    Console.WriteLine("datos no validos");
}